document.getElementById('calcForm').addEventListener('submit', function (event) {
    event.preventDefault();
    var side = parseFloat(document.getElementById('side').value);
    var angle = parseFloat(document.getElementById('angle').value);
    if (isNaN(side) || isNaN(angle)) {
        alert('Kérjük, adjon meg érvényes adatokat!');
        return;
    }
    var angleInRadians = angle * (Math.PI / 180);
    var radius = 0.5 * side * Math.sin(angleInRadians);
    document.getElementById('result').textContent = "A rombuszba \u00EDrhat\u00F3 k\u00F6r sugara: ".concat(radius.toFixed(2));
});
