
/*
 File: app.ts
 Author: Pesztránszki Dániel
 Copyright: 2024, Pesztránszki Dániel
 Group: 2024-25 SZOFT II/2/E
 Date: 2024-11-25
 Github: N/A
 Licenc: GNU GPL
*/
document.getElementById('calcForm')!.addEventListener('submit', function(event) {
    event.preventDefault();
    
    const side = parseFloat((document.getElementById('side') as HTMLInputElement).value);
    const angle = parseFloat((document.getElementById('angle') as HTMLInputElement).value);
    
    if (isNaN(side) || isNaN(angle)) {
        alert('Kérjük, adjon meg érvényes adatokat!');
        return;
    }
    
    const angleInRadians = angle * (Math.PI / 180);
    
    const radius = 0.5 * side * Math.sin(angleInRadians);
    
    document.getElementById('result')!.textContent = `A rombuszba írható kör sugara: ${radius.toFixed(2)} cm`;
});